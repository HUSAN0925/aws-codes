
import json

def lambda_handler(event, context):
    try:
        # Get student details from the JSON test event
        name = event.get("name")
        marks = event.get("marks")
        subject = event.get("subject")

        # Validate required fields
        if name is None or marks is None or subject is None:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "Please provide name, marks, and subject."
                })
            }

        # Validate marks (must be a number, not a boolean)
        if isinstance(marks, bool) or not isinstance(marks, (int, float)):
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "Marks must be a number."
                })
            }

        # Check the valid marks range
        if marks < 0 or marks > 100:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "Marks must be between 0 and 100."
                })
            }

        # Calculate grade
        if marks >= 80:
            grade = "A"
        elif marks >= 70:
            grade = "B"
        elif marks >= 60:
            grade = "C"
        elif marks >= 50:
            grade = "D"
        else:
            grade = "F"

        # Calculate pass/fail status
        status = "Pass" if marks >= 50 else "Fail"

        # Bonus challenge: excellent performance
        result = {
            "student": name,
            "subject": subject,
            "marks": marks,
            "grade": grade,
            "status": status
        }

        if marks >= 90:
            result["message"] = "Excellent Performance"

        # Return JSON response
        return {
            "statusCode": 200,
            "body": json.dumps(result)
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": "An unexpected error occurred."
            })
        }
